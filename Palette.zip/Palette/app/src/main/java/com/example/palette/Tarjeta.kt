package com.example.palette

class Tarjeta(val imagen: Int)